package com.codingbox.dao;

import com.codingbox.vo.RegitVo;

public class UserDao {

	public boolean join(RegitVo vo) {
		// DB Connection
		// insert
		// ...
		
		
		return true;
	}
}
